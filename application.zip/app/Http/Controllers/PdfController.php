<?php

namespace App\Http\Controllers;

use Elibyy\TCPDF\Facades\TCPDF;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Barryvdh\DomPDF\Facade\Pdf;
// use PDF;

//Reference the Dompdf namespace
use Dompdf\Dompdf;

//Reference the option  namespace
use Dompdf\Options;


class PdfController extends Controller
{
    public function index()
    {
        // $filename = 'demo.pdf';

        // $data = [
        //     'title' => 'Generate PDF using laravel TCPDF - webappfix'
        // ];

        // return view('pdfSample', $data);

        // $html = view()->make('pdfSample', $data)->render();

        // $pdf = new PDF;
        // $pdf::SetTitle('Hello World !');
        // $pdf::AddPage('A4');
        // $pdf::writeHTML($html, true,false,true,false,'');

        // $pdf::Output(public_path($filename), 'F');

        // return response()->download(public_path($filename));

    }

    public function generatepdf()
    {
        // $pdf = App::make('dompdf.wrapper');
        // $pdf->loadHTML('<h1>Hello world</h1>');

//         return view('pdfSample');
        $dompdf = new Dompdf();
//        $dompdf->loadHtml($html);
//        $dompdf->render();

        $pdf = Pdf::loadView('pdfSample')->setPaper('A4', '');
        $pdf->output();
        $canvas = $pdf->getDomPDF()->getCanvas();
        $height = $canvas->get_height();
        $width = $canvas->get_width();
//        $canvas->page_script('$pdf->set_opacity(0.1, "Multiply"); $pdf->image(public_path("assets/logo.jpeg"), 0,150, 600, 600);');
        return $pdf->stream('report.pdf');
    }


//     public function watermark()

//     {
//         //Include Autoloader
// // require_once 'dompdf/autoloader.inc.php';


// //Set options to enable embedder PHP
// $options = new Options();
// $options->set('isPhpEnabled', 'true');


// //instantiate dompdf class
// $dompdf = new Dompdf($options);

// //load content from html file


// // $html = file_get_contents("pdfsamlpe");
//  $html = view()->make('pdfSample')->render();

// $dompdf->loadHtml($html);


// $dompdf->setPaper('A4', 'portrait');

// $dompdf->render();

// $canvas = $dompdf->getCanvas();

// $w = $canvas->get_width();
// $h = $canvas->get_height();

// $imageUrl = 'https://trademark.ninoxdb.com/share/gf57zwm5oo3pd76e6j029kuvvx00l7c5pgjh';
// $imgWidth = 156;
// $imgHeight = 156;

// $canvas->set_opacity(.3);

// $x = (($w-$imgWidth)-10);
// $y = (($h-$imgHeight)-20);

// $canvas->image($imageUrl, $x, $y, $imgWidth, $imgHeight);

// $dompdf->stream('document-img.pdf', array('Attachment' => 1));

//     }
}
